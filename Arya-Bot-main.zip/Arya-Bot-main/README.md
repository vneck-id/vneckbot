# Bot Naga
BOT WHATSAPP TERMUX BYE:DRAWL NAG

### Alat dan Bahan
Siapin alat dan bahannya.
```bash
> niat
> 2 handphone (1 buat jalanin sc, 1 buat scan qr)
> internet yang memadai, POKOKNYA 4G +
> aplikasi whatsapp
> aplikasi termux
> kopi
```

### Cara Installnya
Sebelum lu jalanin sc nya install dulu lah.
```bash
> kalo lu belum punya apk termux, download di playstore
> masuk ke apk termux lalu ketik dibawah ini!
> git clone https://github.com/Arya274/Arya-Bot
> cd Arya-Bot
> npm i
> node index.js
> Tinggal scan qr dah
```

## Features

| NFQ BOT       |                Feature           |
| :-----------: | :--------------------------------: |
|       ✅       | Sticker CreatoR                  |
|       ✅       | Kick Grup                        |
|       ✅       | Bucin                            |
|       ✅       | Promote Member                   |
|       ✅       | Add                              |
|       ✅       | Link                             |
|       ✅       | Link Grup                        |
|       ✅       | Ss (web)                         |
|       ✅       | Pengumuman                       |
|       ✅       | List Online                      |
|       ✅       | Fitnah Reply                     |
|       ✅       | Jadi Bot Cepat                   |
|       ✅       | HideTag                          |
|       ✅       | Prefix Random                    |
|       ✅       | Info                             |
|       ✅       | Google Font                      |

## Special Thanks to
* [`NUROTOMO`](https://github.com/Nurotomo)

### SOSMED
* Youtube: Drawl Nag
